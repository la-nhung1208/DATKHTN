const socket = io();

function updateTime() {
  const currentTime = moment().format("HH:mm:ss");
  document.getElementById("thoigian").innerText = currentTime;
}
updateTime();
setInterval(updateTime, 1000);

socket.on("capnhatnhietdo", function (data_received) {
  let hienthinhietdo = data_received;
  document.getElementById("nhietdo").innerHTML = hienthinhietdo + "°C";
});

socket.on("capnhatdoam", function (data_received) {
  let hienthidoam = data_received;
  document.getElementById("doam").innerHTML = hienthidoam + "%";
});
socket.on("capnhatdoamdat", function (data_received) {
  let hienthidoamdat = data_received;
  document.getElementById("doamdat").innerHTML = hienthidoamdat + "%";
});
let relay2sent = false;
let timer2;

let previousSwitch2State = false;
function checkHumidityThreshold() {
  const nguongdoamdat = parseFloat(document.getElementById("nguong2").value);

  if (isNaN(nguongdoamdat)) {
    if (!relay2sent) {
      document.getElementById("switch2").checked = false;
      socket.emit("relayio2", 0);
      relay2sent = true;
    }
  } else {
    let hienthidoamdat = parseFloat(
      document.getElementById("doamdat").innerHTML
    );

    if (nguongdoamdat >= hienthidoamdat) {
      document.getElementById("switch2").checked = true;
      socket.emit("relayio2", 1);
    } else {
      document.getElementById("switch2").checked = false;
      socket.emit("relayio2", 0);
    }
    relay2sent = false;
  }
}

document.getElementById("nguong2").addEventListener("input", function () {
  clearTimeout(timer2);

  timer2 = setTimeout(checkHumidityThreshold, 1000);
});

setInterval(function () {
  checkHumidityThreshold();

  if (document.getElementById("switch2").checked !== previousSwitch2State) {
    socket.emit("relayio2", document.getElementById("switch2").checked ? 1 : 0);
    previousSwitch2State = document.getElementById("switch2").checked;
  }
}, 1000);

socket.on("capnhatcuongdoanhsang", function (data_received) {
  let hienthianhsang = data_received;
  document.getElementById("anhsang").innerHTML = hienthianhsang + " Lx";
});

let relay1sent = false;
let timer1;

let previousSwitchState = false;

function checkLightThreshold() {
  const nguonganhsang = parseFloat(document.getElementById("nguong1").value);

  if (isNaN(nguonganhsang)) {
    if (!relay1sent) {
      document.getElementById("switch1").checked = false;
      socket.emit("relayio1", 0);
      relay1sent = true;
    }
  } else {
    let hienthianhsang = parseFloat(
      document.getElementById("anhsang").innerHTML
    );

    if (nguonganhsang >= hienthianhsang) {
      document.getElementById("switch1").checked = true;
      socket.emit("relayio1", 1);
    } else {
      document.getElementById("switch1").checked = false;
      socket.emit("relayio1", 0);
    }
    relay1sent = false;
  }
}

document.getElementById("nguong1").addEventListener("input", function () {
  clearTimeout(timer1);

  timer1 = setTimeout(checkLightThreshold, 1000);
});

setInterval(function () {
  checkLightThreshold();

  if (document.getElementById("switch1").checked !== previousSwitchState) {
    socket.emit("relayio1", document.getElementById("switch1").checked ? 1 : 0);
    previousSwitchState = document.getElementById("switch1").checked;
  }
}, 1000);

document.getElementById("switch1").addEventListener("change", function () {
  const switchValue1 = this.checked ? 1 : 0;
  socket.emit("relayio1", switchValue1);
});

document.getElementById("switch2").addEventListener("change", function () {
  const switchValue2 = this.checked ? 1 : 0;
  socket.emit("relayio2", switchValue2);
});

let isEventProcessed1 = false;
function checkAndUpdateStatus1() {
  const hour1data = parseInt(document.getElementById("hour1").value);
  const minute1data = parseInt(document.getElementById("minute1").value);
  console.log(hour1data, minute1data);

  const currentTime = moment();
  const currentHour = currentTime.format("HH");
  const currentMinute = currentTime.format("mm");

  if (
    hour1data === parseInt(currentHour) &&
    minute1data === parseInt(currentMinute) &&
    !isEventProcessed1
  ) {
    document.getElementById("switch1").checked = true;
    socket.emit("relayio1", 1);
    isEventProcessed1 = true;

    setTimeout(() => {
      document.getElementById("switch1").checked = false;
      socket.emit("relayio1", 0);
      isEventProcessed1 = false;
    }, 60000);
  }
}
const intervalId1 = setInterval(checkAndUpdateStatus1, 1000);

let isEventProcessed2 = false;
function checkAndUpdateStatus2() {
  const hour2data = parseInt(document.getElementById("hour2").value);
  const minute2data = parseInt(document.getElementById("minute2").value);
  console.log(hour2data, minute2data);

  const currentTime = moment();
  const currentHour = currentTime.format("HH");
  const currentMinute = currentTime.format("mm");

  if (
    hour2data === parseInt(currentHour) &&
    minute2data === parseInt(currentMinute) &&
    !isEventProcessed2
  ) {
    document.getElementById("switch2").checked = true;
    socket.emit("relayio2", 1);
    isEventProcessed2 = true;

    setTimeout(() => {
      document.getElementById("switch2").checked = false;
      socket.emit("relayio2", 0);
      isEventProcessed2 = false;
    }, 60000);
  }
}
const intervalId2 = setInterval(checkAndUpdateStatus2, 1000);
